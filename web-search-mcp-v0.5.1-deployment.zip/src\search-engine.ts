import axios from 'axios';
import * as cheerio from 'cheerio';
import { SearchOptions, SearchResult, SearchResultWithMetadata, ServerConfig } from './types.js';
import { Logger } from './utils.js';
import { generateTimestamp, sanitizeQuery } from './utils.js';
import { RateLimiter } from './rate-limiter.js';
import { BrowserPool } from './browser-pool.js';

export class SearchEngine {
  private readonly rateLimiter: RateLimiter;
  private browserPool: BrowserPool;
  private config: ServerConfig;
  private logger: Logger;

  constructor(config: ServerConfig, browserPool: BrowserPool, logger: Logger) {
    this.config = config;
    this.rateLimiter = new RateLimiter(10); // 10 requests per minute
    this.browserPool = browserPool;
    this.logger = logger;
  }

  async search(options: SearchOptions): Promise<SearchResultWithMetadata> {
    const { query, numResults = 5, timeout = 10000 } = options;
    const sanitizedQuery = sanitizeQuery(query);
    
    this.logger.info(`[SearchEngine] Starting search for query: "${sanitizedQuery}"`);
    
    try {
      return await this.rateLimiter.execute(async () => {
        const enableParallel = this.config.enableParallelSearch;
        const qualityThreshold = this.config.relevanceThreshold;
        
        this.logger.info(`[SearchEngine] Search config: parallel=${enableParallel}, threshold=${qualityThreshold}`);

        // Define available engines
        // Re-order engines based on user request: DDG Lite as primary axios.
        // Also keep Browser Bing as a primary browser choice for variety in parallel.
        const prioritizedEngines = [
          { method: this.tryDuckDuckGoSearch.bind(this), name: 'DDG Lite', type: 'axios' },
          { method: this.tryBrowserBingSearch.bind(this), name: 'Browser Bing', type: 'browser' },
          { method: this.tryAxiosStartpageSearch.bind(this), name: 'Axios Startpage', type: 'axios' },
          { method: this.tryBrowserBraveSearch.bind(this), name: 'Browser Brave', type: 'browser' }
        ];

        // Shuffle only those that aren't the primary ones (optional)
        // or just use the list order for more deterministic performance as the user requested.
        const shuffledEngines = prioritizedEngines;
        
        let results: SearchResult[] = [];
        let usedEngine = 'None';

        if (enableParallel) {
          this.logger.info(`[SearchEngine] Executing parallel search phase (Top 2 engines)...`);
          const top2 = shuffledEngines.slice(0, 2);
          
          const startTime = Date.now();
          const outcomes = await Promise.allSettled(
            top2.map((engine: any) => engine.method(sanitizedQuery, numResults, timeout / 2))
          );

          // Success Switch: Pick the first successful high-quality result
          for (let i = 0; i < outcomes.length; i++) {
            const outcome = outcomes[i];
            if (outcome.status === 'fulfilled' && outcome.value.length > 0) {
              const engineName = top2[i].name;
              const quality = this.assessResultQuality(outcome.value, sanitizedQuery);
              this.logger.info(`[SearchEngine] Parallel engine ${engineName} returned ${outcome.value.length} results (quality: ${quality.toFixed(2)})`);
              
              if (quality >= qualityThreshold || results.length === 0) {
                results = outcome.value;
                usedEngine = engineName;
                if (quality >= qualityThreshold) {
                  this.logger.info(`[SearchEngine] Early exit triggered by ${engineName}`);
                  break;
                }
              }
            }
          }
          
          if (results.length > 0) {
            return { results, engine: usedEngine };
          }
          this.logger.info(`[SearchEngine] Parallel phase failed to find high-quality results in ${Date.now() - startTime}ms. Falling back to waterfall...`);
        }

        // Waterfall Fallback
        for (const engine of shuffledEngines) {
          if (engine.name === usedEngine) continue; // Skip if already tried in parallel

          try {
            this.logger.info(`[SearchEngine] Waterfall: Attempting ${engine.name}...`);
            const engineResults = await engine.method(sanitizedQuery, numResults, timeout / 3);
            if (engineResults.length > 0) {
              const quality = this.assessResultQuality(engineResults, sanitizedQuery);
              if (quality >= (qualityThreshold * 0.8)) {
                return { results: engineResults, engine: engine.name };
              }
              // Keep track of best results if we don't hit threshold
              if (engineResults.length > results.length) {
                results = engineResults;
                usedEngine = engine.name;
              }
            }
          } catch (err) {
            this.logger.error(`[SearchEngine] Waterfall ${engine.name} failed:`, err instanceof Error ? err.message : err);
          }
        }

        return { results, engine: usedEngine };
      });
    } catch (error) {
      this.logger.error('[SearchEngine] Search error:', error);
      throw new Error(`Failed to perform search: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }




  private async tryBrowserBraveSearch(query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    this.logger.info(`[SearchEngine] Trying browser-based Brave search with shared browser pool...`);
    
    // Try with retry mechanism
    for (let attempt = 1; attempt <= 2; attempt++) {
      let browser;
      try {
        browser = await this.browserPool.getBrowser();
        
        this.logger.info(`[SearchEngine] Brave search attempt ${attempt}/2 with shared browser`);
        const results = await this.tryBrowserBraveSearchInternal(browser, query, numResults, timeout);
        return results;
      } catch (error) {
        this.logger.error(`[SearchEngine] Brave search attempt ${attempt}/2 failed:`, error);
        if (attempt === 2) {
          throw error; // Re-throw on final attempt
        }
        // Small delay before retry
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      // Note: We no longer close the browser here since it is managed by BrowserPool
    }
    
    throw new Error('All Brave search attempts failed');
  }

  private async tryBrowserBraveSearchInternal(browser: any, query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    // Validate browser is still functional before proceeding
    if (!browser.isConnected()) {
      throw new Error('Browser is not connected');
    }
    
    try {
      const context = await browser.newContext({
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/121.0.0.0',
        viewport: { width: 1366, height: 768 },
        locale: 'en-US',
        timezoneId: 'America/New_York',
      });

      try {
        const page = await context.newPage();
        
        // Navigate to Brave search
        const searchUrl = `https://search.brave.com/search?q=${encodeURIComponent(query)}&source=web`;
        this.logger.info(`[SearchEngine] Browser navigating to Brave: ${searchUrl}`);
        
        await page.goto(searchUrl, { 
          waitUntil: 'domcontentloaded',
          timeout: timeout
        });

        // Wait for search results to load
        try {
          await page.waitForSelector('[data-type="web"]', { timeout: 3000 });
        } catch {
          this.logger.info(`[SearchEngine] Browser Brave results selector not found, proceeding anyway`);
        }

        const html = await page.content();
        
        this.logger.info(`[SearchEngine] Browser Brave got HTML with length: ${html.length}`);
        
        const results = this.parseBraveResults(html, numResults);
        
        // Ensure context is closed
        await context.close();
        return results;
      } catch (error) {
        // Ensure context is closed even on error
        await context.close();
        throw error;
      }
    } catch (error) {
      this.logger.error(`[SearchEngine] Browser Brave search failed:`, error);
      throw error;
    }
  }

  private async tryBrowserBingSearch(query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    const debugBing = this.config.debugBingSearch;
    this.logger.info(`[SearchEngine] BING: Starting browser-based search with shared browser for query: "${query}"`);
    
    // Try with retry mechanism
    for (let attempt = 1; attempt <= 2; attempt++) {
      let browser;
      try {
        this.logger.info(`[SearchEngine] BING: Attempt ${attempt}/2 - Getting browser from pool...`);
        const startTime = Date.now();
        browser = await this.browserPool.getBrowser();
        
        const launchTime = Date.now() - startTime;
        this.logger.info(`[SearchEngine] BING: Browser acquired successfully in ${launchTime}ms, connected: ${browser.isConnected()}`);
        
        const results = await this.tryBrowserBingSearchInternal(browser, query, numResults, timeout);
        this.logger.info(`[SearchEngine] BING: Search completed successfully with ${results.length} results`);
        return results;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        this.logger.error(`[SearchEngine] BING: Attempt ${attempt}/2 FAILED with error: ${errorMessage}`);
        
        if (debugBing) {
          this.logger.info(`[SearchEngine] BING: Full error details:`, error);
        }
        
        if (attempt === 2) {
          this.logger.error(`[SearchEngine] BING: All attempts exhausted, giving up`);
          throw error; // Re-throw on final attempt
        }
        // Small delay before retry
        this.logger.info(`[SearchEngine] BING: Waiting 500ms before retry...`);
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      // Note: We no longer close the browser here since it is managed by BrowserPool
    }
    
    throw new Error('All Bing search attempts failed');
  }

  private async tryBrowserBingSearchInternal(browser: any, query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    const debugBing = this.config.debugBingSearch;
    
    // Validate browser is still functional before proceeding
    if (!browser.isConnected()) {
      this.logger.error(`[SearchEngine] BING: Browser is not connected`);
      throw new Error('Browser is not connected');
    }
    
    this.logger.info(`[SearchEngine] BING: Creating browser context with enhanced fingerprinting...`);
    
    try {
      // Enhanced browser context with more realistic fingerprinting
      const context = await browser.newContext({
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/121.0.0.0',
        viewport: { width: 1366, height: 768 },
        locale: 'en-US',
        timezoneId: 'America/New_York',
        colorScheme: 'light',
        deviceScaleFactor: 1,
        hasTouch: false,
        isMobile: false,
        extraHTTPHeaders: {
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate, br',
          'DNT': '1',
          'Upgrade-Insecure-Requests': '1',
          'Sec-Fetch-Dest': 'document',
          'Sec-Fetch-Mode': 'navigate',
          'Sec-Fetch-Site': 'none'
        }
      });

      this.logger.info(`[SearchEngine] BING: Context created, opening new page...`);
      const page = await context.newPage();
      this.logger.info(`[SearchEngine] BING: Page opened successfully`);
      
      try {
        // Try enhanced Bing search with proper web interface flow
        try {
          this.logger.info(`[SearchEngine] BING: Attempting enhanced search (homepage → form submission)...`);
          const results = await this.tryEnhancedBingSearch(page, query, numResults, timeout);
          this.logger.info(`[SearchEngine] BING: Enhanced search succeeded with ${results.length} results`);
          await context.close();
          return results;
        } catch (enhancedError) {
          const errorMessage = enhancedError instanceof Error ? enhancedError.message : 'Unknown error';
          this.logger.info(`[SearchEngine] BING: Enhanced search failed: ${errorMessage}`);
          
          if (debugBing) {
            this.logger.info(`[SearchEngine] BING: Enhanced search error details:`, enhancedError);
          }
          
          this.logger.info(`[SearchEngine] BING: Falling back to direct URL search...`);
          
          // Fallback to direct URL approach with enhanced parameters
          const results = await this.tryDirectBingSearch(page, query, numResults, timeout);
          this.logger.info(`[SearchEngine] BING: Direct search succeeded with ${results.length} results`);
          await context.close();
          return results;
        }
      } catch (error) {
        // Ensure context is closed even on error
        this.logger.info(`[SearchEngine] BING: All search methods failed, closing context...`);
        await context.close();
        throw error;
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      this.logger.error(`[SearchEngine] BING: Internal search failed: ${errorMessage}`);
      
      if (debugBing) {
        this.logger.info(`[SearchEngine] BING: Internal search error details:`, error);
      }
      
      throw error;
    }
  }

  private async tryEnhancedBingSearch(page: any, query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    const debugBing = this.config.debugBingSearch;
    this.logger.info(`[SearchEngine] BING: Enhanced search - navigating to Bing homepage...`);
    
    // Navigate to Bing homepage first to establish proper session
    const startTime = Date.now();
    await page.goto('https://www.bing.com', { 
      waitUntil: 'domcontentloaded',
      timeout: timeout / 2
    });
    
    const loadTime = Date.now() - startTime;
    const pageTitle = await page.title();
    const currentUrl = page.url();
    this.logger.info(`[SearchEngine] BING: Homepage loaded in ${loadTime}ms, title: "${pageTitle}", URL: ${currentUrl}`);
    
    // Wait a moment for page to fully load
    await page.waitForTimeout(500);
    
    // Find and use the search box (more realistic than direct URL)
    try {
      this.logger.info(`[SearchEngine] BING: Looking for search form elements...`);
      await page.waitForSelector('#sb_form_q', { timeout: 2000 });
      this.logger.info(`[SearchEngine] BING: Search box found, filling with query: "${query}"`);
      await page.fill('#sb_form_q', query);
      
      this.logger.info(`[SearchEngine] BING: Clicking search button and waiting for navigation...`);
      // Submit the search form
      await Promise.all([
        page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: timeout }),
        page.click('#search_icon')
      ]);
      
      const searchLoadTime = Date.now() - startTime;
      const searchPageTitle = await page.title();
      const searchPageUrl = page.url();
      this.logger.info(`[SearchEngine] BING: Search completed in ${searchLoadTime}ms total, title: "${searchPageTitle}", URL: ${searchPageUrl}`);
      
    } catch (formError) {
      const errorMessage = formError instanceof Error ? formError.message : 'Unknown error';
      this.logger.info(`[SearchEngine] BING: Search form submission failed: ${errorMessage}`);
      
      if (debugBing) {
        this.logger.info(`[SearchEngine] BING: Form error details:`, formError);
      }
      
      throw formError;
    }
    
    // Wait for search results to load
    try {
      this.logger.info(`[SearchEngine] BING: Waiting for search results to appear...`);
      await page.waitForSelector('.b_algo, .b_result', { timeout: 3000 });
      this.logger.info(`[SearchEngine] BING: Search results selector found`);
    } catch {
      this.logger.info(`[SearchEngine] BING: Search results selector not found, proceeding with page content anyway`);
    }

    const html = await page.content();
    this.logger.info(`[SearchEngine] BING: Got page HTML with length: ${html.length} characters`);
    
    if (debugBing && html.length < 10000) {
      this.logger.warn(`[SearchEngine] BING: WARNING - HTML seems short, possible bot detection or error page`);
    }
    
    const results = this.parseBingResults(html, numResults);
    this.logger.info(`[SearchEngine] BING: Enhanced search parsed ${results.length} results`);
    
    if (results.length === 0) {
      this.logger.warn(`[SearchEngine] BING: WARNING - No results found, possible parsing failure or empty search`);
      
      if (debugBing) {
        const sampleHtml = html.substring(0, 1000);
        this.logger.info(`[SearchEngine] BING: Sample HTML for debugging:`, sampleHtml);
      }
    }
    
    return results;
  }

  private async tryDirectBingSearch(page: any, query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    const debugBing = this.config.debugBingSearch;
    const cvid = this.generateConversationId();
    const searchUrl = `https://www.bing.com/search?q=${encodeURIComponent(query)}&count=${Math.min(numResults, 10)}&form=QBLH&sp=-1&qs=n&cvid=${cvid}`;
    const startTime = Date.now();
    
    try {
      this.logger.info(`[SearchEngine] BING: Direct search - navigating to: ${searchUrl}`);
      await page.goto(searchUrl, { 
        waitUntil: 'domcontentloaded',
        timeout: timeout
      });
      
      const loadTime = Date.now() - startTime;
      const pageTitle = await page.title();
      this.logger.info(`[SearchEngine] BING: Direct search page loaded in ${loadTime}ms, title: "${pageTitle}"`);
      
      // Wait for results
      try {
        await page.waitForSelector('.b_algo, .b_result', { timeout: 3000 });
      } catch {
        this.logger.info(`[SearchEngine] BING: Direct search results selector not found, proceeding...`);
      }

      const html = await page.content();
      this.logger.info(`[SearchEngine] BING: Direct search got HTML with length: ${html.length} characters`);
      
      if (debugBing && html.length < 10000) {
        this.logger.warn(`[SearchEngine] BING: WARNING - Direct search HTML seems short`);
      }
      
      const results = this.parseBingResults(html, numResults);
      this.logger.info(`[SearchEngine] BING: Direct search parsed ${results.length} results`);
      
      return results;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      this.logger.error(`[SearchEngine] BING: Direct search failed: ${errorMessage}`);
      throw error;
    }
  }

  private generateConversationId(): string {
    // Generate a conversation ID similar to Bing's format (32 hex characters)
    const chars = '0123456789ABCDEF';
    let cvid = '';
    for (let i = 0; i < 32; i++) {
      cvid += chars[Math.floor(Math.random() * chars.length)];
    }
    return cvid;
  }


  private async tryDuckDuckGoSearch(query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    this.logger.info(`[SearchEngine] Trying DuckDuckGo as fallback...`);
    
    try {
      const response = await axios.get('https://html.duckduckgo.com/html/', {
        params: {
          q: query,
        },
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/122.0.0.0',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
          'Accept-Language': 'en-US,en;q=0.9',
          'Referer': 'https://duckduckgo.com/',
          'DNT': '1',
          'Upgrade-Insecure-Requests': '1',
        },
        timeout,
        validateStatus: (status: number) => status < 400,
      });

      this.logger.info(`[SearchEngine] DuckDuckGo Lite got response with status: ${response.status}`);
      
      const results = this.parseDuckDuckGoResults(response.data, numResults);
      this.logger.info(`[SearchEngine] DuckDuckGo Lite parsed ${results.length} results`);
      
      return results;
    } catch (error) {
      this.logger.info(`[SearchEngine] DuckDuckGo Lite search failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return [];
    }
  }

  private async tryAxiosStartpageSearch(query: string, numResults: number, timeout: number): Promise<SearchResult[]> {
    this.logger.info(`[SearchEngine] Trying Startpage (Axios)...`);
    
    try {
      const response = await axios.get('https://www.startpage.com/sp/search', {
        params: {
          query,
          cat: 'web',
          lui: 'english',
          language: 'english',
          t: 'device',
          sc: 'xkl08PIP6K7120'
        },
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/122.0.0.0',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
          'Referer': 'https://www.startpage.com/',
        },
        timeout,
        validateStatus: (status: number) => status < 400,
      });

      const results = this.parseStartpageResults(response.data, numResults);
      this.logger.info(`[SearchEngine] Startpage parsed ${results.length} results`);
      return results;
    } catch (error) {
      this.logger.info(`[SearchEngine] Startpage search failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return [];
    }
  }

  private parseStartpageResults(html: string, maxResults: number): SearchResult[] {
    const $ = cheerio.load(html);
    const results: SearchResult[] = [];
    const timestamp = generateTimestamp();

    const resultElements = $('.w-gl .result, .result');
    
    resultElements.each((_index, element) => {
      if (results.length >= maxResults) return false;

      const $element = $(element);
      const $titleLink = $element.find('a.result-title').first();
      
      if ($titleLink.length) {
        const title = $titleLink.text().trim();
        const url = $titleLink.attr('href') || '';
        const description = $element.find('.description').text().trim();

        if (title && url && this.isValidSearchUrl(url)) {
          results.push({
            title,
            url,
            description: description || 'No description available',
            fullContent: '',
            contentPreview: '',
            wordCount: 0,
            timestamp,
            fetchStatus: 'success',
          });
        }
      }
    });

    return results;
  }


  private parseSearchResults(html: string, maxResults: number): SearchResult[] {
    this.logger.info(`[SearchEngine] Parsing HTML with length: ${html.length}`);
    
    const $ = cheerio.load(html);
    const results: SearchResult[] = [];
    const timestamp = generateTimestamp();

    // Log what selectors we find - more comprehensive debugging
    const gElements = $('div.g');
    const sokobanElements = $('div[data-sokoban-container]');
    const tF2CxcElements = $('.tF2Cxc');
    const rcElements = $('.rc');
    const vedElements = $('[data-ved]');
    const h3Elements = $('h3');
    const linkElements = $('a[href]');
    
    this.logger.info(`[SearchEngine] Found elements:`);
    this.logger.info(`  - div.g: ${gElements.length}`);
    this.logger.info(`  - div[data-sokoban-container]: ${sokobanElements.length}`);
    this.logger.info(`  - .tF2Cxc: ${tF2CxcElements.length}`);
    this.logger.info(`  - .rc: ${rcElements.length}`);
    this.logger.info(`  - [data-ved]: ${vedElements.length}`);
    this.logger.info(`  - h3: ${h3Elements.length}`);
    this.logger.info(`  - a[href]: ${linkElements.length}`);
    
    // Try multiple approaches to find search results
    const searchResultSelectors = [
      'div.g',
      'div[data-sokoban-container]',
      '.tF2Cxc',
      '.rc',
      '[data-ved]',
      'div[jscontroller]'
    ];
    
    let foundResults = false;
    
    for (const selector of searchResultSelectors) {
      if (foundResults) break;
      
      this.logger.info(`[SearchEngine] Trying selector: ${selector}`);
      const elements = $(selector);
      this.logger.info(`[SearchEngine] Found ${elements.length} elements with selector ${selector}`);
      
      elements.each((_index, element) => {
        if (results.length >= maxResults) return false;
        
        const $element = $(element);
        
        // Try multiple title selectors
        const titleSelectors = ['h3', '.LC20lb', '.DKV0Md', 'a[data-ved]', '.r', '.s'];
        let title = '';
        let url = '';
        
        for (const titleSelector of titleSelectors) {
          const $title = $element.find(titleSelector).first();
          if ($title.length) {
            title = $title.text().trim();
            this.logger.info(`[SearchEngine] Found title with ${titleSelector}: "${title}"`);
            
            // Try to find the link
            const $link = $title.closest('a');
            if ($link.length) {
              url = $link.attr('href') || '';
              this.logger.info(`[SearchEngine] Found URL: "${url}"`);
            } else {
              // Try to find any link in the element
              const $anyLink = $element.find('a[href]').first();
              if ($anyLink.length) {
                url = $anyLink.attr('href') || '';
                this.logger.info(`[SearchEngine] Found URL from any link: "${url}"`);
              }
            }
            break;
          }
        }
        
        // Try multiple snippet selectors
        const snippetSelectors = ['.VwiC3b', '.st', '.aCOpRe', '.IsZvec', '.s3v9rd', '.MUxGbd', '.aCOpRe', '.snippet-content'];
        let snippet = '';
        
        for (const snippetSelector of snippetSelectors) {
          const $snippet = $element.find(snippetSelector).first();
          if ($snippet.length) {
            snippet = $snippet.text().trim();
            this.logger.info(`[SearchEngine] Found snippet with ${snippetSelector}: "${snippet.substring(0, 100)}..."`);
            break;
          }
        }
        
        if (title && url && this.isValidSearchUrl(url)) {
          this.logger.info(`[SearchEngine] Adding result: ${title}`);
          results.push({
            title,
            url: this.cleanGoogleUrl(url),
            description: snippet || 'No description available',
            fullContent: '',
            contentPreview: '',
            wordCount: 0,
            timestamp,
            fetchStatus: 'success',
          });
          foundResults = true;
        } else {
          this.logger.info(`[SearchEngine] Skipping result: title="${title}", url="${url}", isValid=${this.isValidSearchUrl(url)}`);
        }
      });
    }

    this.logger.info(`[SearchEngine] Found ${results.length} results with all selectors`);

    // If still no results, try a more aggressive approach - look for any h3 with links
    if (results.length === 0) {
      this.logger.info(`[SearchEngine] No results found, trying aggressive h3 search...`);
      $('h3').each((_index, element) => {
        if (results.length >= maxResults) return false;
        
        const $h3 = $(element);
        const title = $h3.text().trim();
        const $link = $h3.closest('a');
        
        if ($link.length && title) {
          const url = $link.attr('href') || '';
          this.logger.info(`[SearchEngine] Aggressive search found: "${title}" -> "${url}"`);
          
          if (this.isValidSearchUrl(url)) {
            results.push({
              title,
              url: this.cleanGoogleUrl(url),
              description: 'No description available',
              fullContent: '',
              contentPreview: '',
              wordCount: 0,
              timestamp,
              fetchStatus: 'success',
            });
          }
        }
      });
      
      this.logger.info(`[SearchEngine] Aggressive search found ${results.length} results`);
    }

    return results;
  }

  private parseBraveResults(html: string, maxResults: number): SearchResult[] {
    this.logger.info(`[SearchEngine] Parsing Brave HTML with length: ${html.length}`);
    
    const $ = cheerio.load(html);
    const results: SearchResult[] = [];
    const timestamp = generateTimestamp();

    // Brave result selectors
    const resultSelectors = [
      '[data-type="web"]',     // Main Brave results
      '.result',               // Alternative format
      '.fdb'                   // Brave specific format
    ];
    
    let foundResults = false;
    
    for (const selector of resultSelectors) {
      if (foundResults && results.length >= maxResults) break;
      
      this.logger.info(`[SearchEngine] Trying Brave selector: ${selector}`);
      const elements = $(selector);
      this.logger.info(`[SearchEngine] Found ${elements.length} elements with selector ${selector}`);
      
      elements.each((_index, element) => {
        if (results.length >= maxResults) return false;

        const $element = $(element);
        
        // Try multiple title selectors for Brave
        const titleSelectors = [
          '.title a',              // Brave specific
          'h2 a',                  // Common format  
          '.result-title a',       // Alternative format
          'a[href*="://"]',        // Any external link
          '.snippet-title a'       // Snippet title
        ];
        
        let title = '';
        let url = '';
        
        for (const titleSelector of titleSelectors) {
          const $titleElement = $element.find(titleSelector).first();
          if ($titleElement.length) {
            title = $titleElement.text().trim();
            url = $titleElement.attr('href') || '';
            this.logger.info(`[SearchEngine] Brave found title with ${titleSelector}: "${title}"`);
            if (title && url && url.startsWith('http')) {
              break;
            }
          }
        }
        
        // If still no title, try getting it from any text content
        if (!title) {
          const textContent = $element.text().trim();
          const lines = textContent.split('\n').filter(line => line.trim().length > 0);
          if (lines.length > 0) {
            title = lines[0].trim();
            this.logger.info(`[SearchEngine] Brave found title from text content: "${title}"`);
          }
        }
        
        // Try multiple snippet selectors for Brave
        const snippetSelectors = [
          '.snippet-content',      // Brave specific
          '.snippet',              // Generic
          '.description',          // Alternative
          'p'                      // Fallback paragraph
        ];
        
        let snippet = '';
        for (const snippetSelector of snippetSelectors) {
          const $snippetElement = $element.find(snippetSelector).first();
          if ($snippetElement.length) {
            snippet = $snippetElement.text().trim();
            break;
          }
        }
        
        if (title && url && this.isValidSearchUrl(url)) {
          this.logger.info(`[SearchEngine] Brave found: "${title}" -> "${url}"`);
          results.push({
            title,
            url: this.cleanBraveUrl(url),
            description: snippet || 'No description available',
            fullContent: '',
            contentPreview: '',
            wordCount: 0,
            timestamp,
            fetchStatus: 'success',
          });
          foundResults = true;
        }
      });
    }

    this.logger.info(`[SearchEngine] Brave found ${results.length} results`);
    return results;
  }

  private parseDuckDuckGoResults(html: string, maxResults: number): SearchResult[] {
    this.logger.info(`[SearchEngine] Parsing DuckDuckGo Lite HTML with length: ${html.length}`);
    
    const $ = cheerio.load(html);
    const results: SearchResult[] = [];
    const timestamp = generateTimestamp();

    const resultElements = $('.result');
    
    resultElements.each((_index, element) => {
      if (results.length >= maxResults) return false;

      const $element = $(element);
      const $titleLink = $element.find('.result__title a').first();
      
      if ($titleLink.length) {
        const title = $titleLink.text().trim();
        const rawUrl = $titleLink.attr('href') || '';
        const url = rawUrl;
        const description = $element.find('.result__snippet').text().trim();

        if (title && url && this.isValidSearchUrl(url)) {
          results.push({
            title,
            url,
            description: description || 'No description available',
            fullContent: '',
            contentPreview: '',
            wordCount: 0,
            timestamp,
            fetchStatus: 'success',
          });
        }
      }
    });

    this.logger.info(`[SearchEngine] DuckDuckGo Lite found ${results.length} results`);
    return results;
  }

  private parseBingResults(html: string, maxResults: number): SearchResult[] {
    const debugBing = this.config.debugBingSearch;
    this.logger.info(`[SearchEngine] BING: Parsing HTML with length: ${html.length}`);
    
    const $ = cheerio.load(html);
    const results: SearchResult[] = [];
    const timestamp = generateTimestamp();

    // Check for common Bing error indicators
    const pageTitle = $('title').text();
    this.logger.info(`[SearchEngine] BING: Page title: "${pageTitle}"`);
    
    if (pageTitle.includes('Access Denied') || pageTitle.includes('blocked') || pageTitle.includes('captcha')) {
      this.logger.info(`[SearchEngine] BING: ERROR - Bot detection or access denied detected in page title`);
    }

    // Bing result selectors
    const resultSelectors = [
      '.b_algo',     // Main Bing results
      '.b_result',   // Alternative Bing format
      '.b_card'      // Card format
    ];
    
    this.logger.info(`[SearchEngine] BING: Checking for result elements...`);
    
    // Log counts for all selectors first
    for (const selector of resultSelectors) {
      const elements = $(selector);
      this.logger.info(`[SearchEngine] BING: Found ${elements.length} elements with selector "${selector}"`);
    }
    
    let foundResults = false;
    
    for (const selector of resultSelectors) {
      if (foundResults && results.length >= maxResults) break;
      
      const elements = $(selector);
      if (elements.length === 0) continue;
      
      elements.each((_index, element) => {
        if (results.length >= maxResults) return false;

        const $element = $(element);
        
        // Try multiple title selectors for Bing
        const titleSelectors = [
          'h2 a',           // Standard Bing format
          '.b_title a',     // Alternative format
          'a[data-seid]'    // Bing specific
        ];
        
        let title = '';
        let url = '';
        
        for (const titleSelector of titleSelectors) {
          const $titleElement = $element.find(titleSelector).first();
          if ($titleElement.length) {
            title = $titleElement.text().trim();
            url = $titleElement.attr('href') || '';
            this.logger.info(`[SearchEngine] Bing found title with ${titleSelector}: "${title}"`);
            break;
          }
        }
        
        // Try multiple snippet selectors for Bing
        const snippetSelectors = [
          '.b_caption p',           // Standard Bing snippet
          '.b_snippet',             // Alternative format
          '.b_descript',            // Description format
          '.b_caption',             // Caption without p tag
          '.b_caption > span',      // Caption span
          '.b_excerpt',             // Excerpt format
          'p',                      // Any paragraph in the result
          '.b_algo_content p',      // Content paragraph
          '.b_algo_content',        // Full content area
          '.b_context'              // Context information
        ];
        
        let snippet = '';
        for (const snippetSelector of snippetSelectors) {
          const $snippetElement = $element.find(snippetSelector).first();
          if ($snippetElement.length) {
            const candidateSnippet = $snippetElement.text().trim();
            // Skip very short snippets or those that look like metadata
            if (candidateSnippet.length > 20 && !candidateSnippet.match(/^\d+\s*(min|sec|hour|day|week|month|year)/i)) {
              snippet = candidateSnippet;
              this.logger.info(`[SearchEngine] Bing found snippet with ${snippetSelector}: "${snippet.substring(0, 100)}..."`);
              break;
            }
          }
        }
        
        if (title && url && this.isValidSearchUrl(url)) {
          this.logger.info(`[SearchEngine] Bing found: "${title}" -> "${url}"`);
          results.push({
            title,
            url: this.cleanBingUrl(url),
            description: snippet || 'No description available',
            fullContent: '',
            contentPreview: '',
            wordCount: 0,
            timestamp,
            fetchStatus: 'success',
          });
          foundResults = true;
        }
      });
    }

    this.logger.info(`[SearchEngine] Bing found ${results.length} results`);
    return results;
  }

  private isValidSearchUrl(url: string): boolean {
    // Google search results URLs can be in various formats
    return url.startsWith('/url?') || 
           url.startsWith('http://') || 
           url.startsWith('https://') ||
           url.startsWith('//') ||
           url.startsWith('/search?') ||
           url.startsWith('/') ||
           url.includes('google.com') ||
           url.length > 10; // Accept any reasonably long URL
  }

  private cleanGoogleUrl(url: string): string {
    // Handle Google's redirect URLs
    if (url.startsWith('/url?')) {
      try {
        const urlParams = new URLSearchParams(url.substring(5));
        const actualUrl = urlParams.get('q') || urlParams.get('url');
        if (actualUrl) {
          return actualUrl;
        }
      } catch {
        this.logger.info('Failed to parse Google redirect URL:', url);
      }
    }

    // Handle protocol-relative URLs
    if (url.startsWith('//')) {
      return 'https:' + url;
    }

    return url;
  }

  private cleanBraveUrl(url: string): string {
    // Brave URLs are usually direct, but check for any redirect patterns
    if (url.startsWith('//')) {
      return 'https:' + url;
    }
    
    // If it's already a full URL, return as-is
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    
    return url;
  }

  private cleanBingUrl(url: string): string {
    // Bing URLs are usually direct, but check for any redirect patterns
    if (url.startsWith('//')) {
      return 'https:' + url;
    }
    
    // If it's already a full URL, return as-is
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    
    return url;
  }

  private cleanDuckDuckGoUrl(url: string): string {
    // DuckDuckGo URLs are redirect URLs that need to be decoded
    if (url.startsWith('//duckduckgo.com/l/')) {
      try {
        // Extract the uddg parameter which contains the actual URL
        const urlParams = new URLSearchParams(url.substring(url.indexOf('?') + 1));
        const actualUrl = urlParams.get('uddg');
        if (actualUrl) {
          // Decode the URL
          const decodedUrl = decodeURIComponent(actualUrl);
          this.logger.info(`[SearchEngine] Decoded DuckDuckGo URL: ${decodedUrl}`);
          return decodedUrl;
        }
      } catch {
        this.logger.info(`[SearchEngine] Failed to decode DuckDuckGo URL: ${url}`);
      }
    }
    
    // If it's a protocol-relative URL, add https:
    if (url.startsWith('//')) {
      return 'https:' + url;
    }
    
    return url;
  }

  private assessResultQuality(results: SearchResult[], originalQuery: string): number {
    if (results.length === 0) return 0;

    // Extract keywords from the original query (ignore common words)
    const commonWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'group', 'members']);
    const queryWords = originalQuery.toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2 && !commonWords.has(word));

    if (queryWords.length === 0) return 0.5; // Default score if no meaningful keywords

    this.logger.info(`[SearchEngine] Quality assessment - Query keywords: [${queryWords.join(', ')}]`);

    let totalScore = 0;
    let scoredResults = 0;

    for (const result of results) {
      const titleText = result.title.toLowerCase();
      const descText = result.description.toLowerCase();
      const urlText = result.url.toLowerCase();
      const combinedText = `${titleText} ${descText} ${urlText}`;

      // Count keyword matches
      let keywordMatches = 0;
      let phraseMatches = 0;

      // Check for exact phrase matches (higher value)
      if (queryWords.length >= 2) {
        const queryPhrases = [];
        for (let i = 0; i < queryWords.length - 1; i++) {
          queryPhrases.push(queryWords.slice(i, i + 2).join(' '));
        }
        if (queryWords.length >= 3) {
          queryPhrases.push(queryWords.slice(0, 3).join(' '));
        }

        for (const phrase of queryPhrases) {
          if (combinedText.includes(phrase)) {
            phraseMatches++;
          }
        }
      }

      // Check individual keyword matches
      for (const keyword of queryWords) {
        if (combinedText.includes(keyword)) {
          keywordMatches++;
        }
      }

      // Calculate score for this result
      const keywordRatio = keywordMatches / queryWords.length;
      const phraseBonus = phraseMatches * 0.3; // Bonus for phrase matches
      const resultScore = Math.min(1.0, keywordRatio + phraseBonus);

      // Penalty for obvious irrelevant content
      const irrelevantPatterns = [
        /recipe/i, /cooking/i, /food/i, /restaurant/i, /menu/i,
        /weather/i, /temperature/i, /forecast/i,
        /shopping/i, /sale/i, /price/i, /buy/i, /store/i,
        /movie/i, /film/i, /tv show/i, /entertainment/i,
        /sports/i, /game/i, /score/i, /team/i,
        /fashion/i, /clothing/i, /style/i,
        /travel/i, /hotel/i, /flight/i, /vacation/i,
        /car/i, /vehicle/i, /automotive/i,
        /real estate/i, /property/i, /house/i, /apartment/i
      ];

      let penalty = 0;
      for (const pattern of irrelevantPatterns) {
        if (pattern.test(combinedText)) {
          penalty += 0.2;
        }
      }

      const finalScore = Math.max(0, resultScore - penalty);
      
      this.logger.info(`[SearchEngine] Result "${result.title.substring(0, 50)}..." - Score: ${finalScore.toFixed(2)} (keywords: ${keywordMatches}/${queryWords.length}, phrases: ${phraseMatches}, penalty: ${penalty.toFixed(2)})`);
      
      totalScore += finalScore;
      scoredResults++;
    }

    const averageScore = scoredResults > 0 ? totalScore / scoredResults : 0;
    return averageScore;
  }

  private async validateBrowserHealth(browser: any): Promise<boolean> {
    try {
      this.logger.info(`[SearchEngine] Validating browser health...`);
      
      // Check if browser is still connected
      if (!browser.isConnected()) {
        this.logger.info(`[SearchEngine] Browser is not connected`);
        return false;
      }
      
      // Try to create a simple context to test browser responsiveness
      const testContext = await browser.newContext();
      await testContext.close();
      
      this.logger.info(`[SearchEngine] Browser health check passed`);
      return true;
    } catch (error) {
      this.logger.error(`[SearchEngine] Browser health check failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return false;
    }
  }

  private async handleBrowserError(error: any, engineName: string, attemptNumber: number = 1): Promise<void> {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    this.logger.error(`[SearchEngine] ${engineName} browser error (attempt ${attemptNumber}): ${errorMessage}`);
    
    // Check for specific browser-related errors
    if (errorMessage.includes('Target page, context or browser has been closed') ||
        errorMessage.includes('Browser has been closed') ||
        errorMessage.includes('Session has been closed')) {
      
      this.logger.info(`[SearchEngine] Detected browser session closure, attempting to refresh browser pool`);
      
      // Try to refresh the browser pool for subsequent attempts
      try {
        await this.browserPool.closeAll();
        this.logger.info(`[SearchEngine] Browser pool refreshed for ${engineName}`);
      } catch (refreshError) {
        this.logger.error(`[SearchEngine] Failed to refresh browser pool: ${refreshError instanceof Error ? refreshError.message : 'Unknown error'}`);
      }
    }
  }

  async closeAll(): Promise<void> {
    await this.browserPool.closeAll();
  }

  private shuffleArray<T>(array: T[]): T[] {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
  }
}
