#!/usr/bin/env node
// The actual startup message is handled by Logger.force in the constructor

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { z } from 'zod';
import express from 'express';
import { Command } from 'commander';
import { SearchEngine } from './search-engine.js';
import { EnhancedContentExtractor } from './enhanced-content-extractor.js';
import { WebSearchToolInput, WebSearchToolOutput, SearchResult, ServerConfig } from './types.js';
import { BrowserPool } from './browser-pool.js';
import { isPdfUrl, Logger } from './utils.js';
import crypto from 'node:crypto';

interface RunOptions {
  transport: 'stdio' | 'http';
  port?: number;
  playwrightNoSandbox?: boolean;
}

class WebSearchMCPServer {
  private server: McpServer;
  private searchEngine: SearchEngine;
  private contentExtractor: EnhancedContentExtractor;
  private config: ServerConfig;
  private browserPool: BrowserPool;
  private logger: Logger;

  constructor(cliConfig?: { playwrightNoSandbox?: boolean }) {
    this.server = new McpServer({
      name: 'web-search-mcp-server',
      version: '0.5.1',
    });

    this.config = this.parseConfig(cliConfig);
    this.logger = new Logger(this.config.verboseLogging);
    
    this.logger.force('Web Search MCP Server starting...');

    this.browserPool = new BrowserPool(this.config, this.logger);
    this.searchEngine = new SearchEngine(this.config, this.browserPool, this.logger);
    this.contentExtractor = new EnhancedContentExtractor(this.config, this.browserPool, this.logger);

    this.setupTools();
    this.setupGracefulShutdown();
  }

  private parseConfig(cliConfig?: { playwrightNoSandbox?: boolean }): ServerConfig {
    const maxContentLengthParsed = parseInt(process.env.MAX_CONTENT_LENGTH || '500000', 10);
    
    // Determine no-sandbox: CLI flag > Env Var > Default (true)
    let playwrightNoSandbox = true;
    if (cliConfig?.playwrightNoSandbox !== undefined) {
      playwrightNoSandbox = cliConfig.playwrightNoSandbox;
    } else if (process.env.PLAYWRIGHT_NO_SANDBOX === 'false') {
      playwrightNoSandbox = false;
    }

    return {
      maxContentLength: isNaN(maxContentLengthParsed) || maxContentLengthParsed < 0 ? 500000 : maxContentLengthParsed,
      defaultTimeout: parseInt(process.env.DEFAULT_TIMEOUT || '6000', 10),
      maxBrowsers: parseInt(process.env.MAX_BROWSERS || '3', 10),
      browserHeadless: process.env.BROWSER_HEADLESS !== 'false',
      browserTypes: (process.env.BROWSER_TYPES || 'chromium,firefox').split(',').map(type => type.trim()),
      browserFallbackThreshold: parseInt(process.env.BROWSER_FALLBACK_THRESHOLD || '3', 10),
      enableRelevanceChecking: process.env.ENABLE_RELEVANCE_CHECKING !== 'false',
      relevanceThreshold: parseFloat(process.env.RELEVANCE_THRESHOLD || '0.3'),
      forceMultiEngineSearch: process.env.FORCE_MULTI_ENGINE_SEARCH === 'true',
      debugBrowserLifecycle: process.env.DEBUG_BROWSER_LIFECYCLE === 'true',
      debugBingSearch: process.env.DEBUG_BING_SEARCH === 'true',
      playwrightNoSandbox,
      browserIdleTimeout: parseInt(process.env.BROWSER_IDLE_TIMEOUT || '120000', 10),
      enableParallelSearch: process.env.ENABLE_PARALLEL_SEARCH !== 'false',
      verboseLogging: process.env.VERBOSE_LOGGING === 'true'
    };
  }

  private setupTools(): void {
    // Register the main web search tool (primary choice for comprehensive searches)
    this.server.tool(
      'full-web-search',
      'Search the web and fetch complete page content from top results. This is the most comprehensive web search tool. It searches the web and then follows the resulting links to extract their full page content, providing the most detailed and complete information available. Use get-web-search-summaries for a lightweight alternative.',
      {
        query: z.string().describe('Search query to execute (recommended for comprehensive research)'),
        limit: z.number().int().min(1).max(10).default(5).describe('Number of results to return with full content (1-10)'),
        includeContent: z.boolean().default(true).describe('Whether to fetch full page content (default: true)'),
        maxContentLength: z.number().int().min(0).optional().describe('Maximum characters per result content (0 = no limit)'),
      },
      async (args) => {
        this.logger.info(`[MCP] Tool call received: full-web-search`);
        this.logger.info(`[MCP] Raw arguments:`, JSON.stringify(args, null, 2));

        try {
          // Arguments are already validated by Zod via McpServer.tool
          const validatedArgs = args as WebSearchToolInput;
          
          // Auto-detect model types based on parameter formats
          // Some models might still send string-like inputs if not using strict JSON schema, 
          // but Zod should have handled the core validation.
          
          // Llama models often struggle with large responses
          const isLikelyLlama = typeof args === 'object' && args !== null && (
            ('limit' in args && typeof (args as any).limit === 'string') ||
            ('includeContent' in args && typeof (args as any).includeContent === 'string')
          );
          
          // Detect models that handle large responses well
          const isLikelyRobustModel = typeof args === 'object' && args !== null && (
            ('limit' in args && typeof (args as any).limit === 'number') &&
            ('includeContent' in args && typeof (args as any).includeContent === 'boolean')
          );
          
          // Only apply auto-limit if maxContentLength is not explicitly set (including 0)
          const hasExplicitMaxLength = typeof args === 'object' && args !== null && 'maxContentLength' in args;
          
          if (!hasExplicitMaxLength && isLikelyLlama) {
            this.logger.info(`[MCP] Detected potential Llama model, applying content length limit`);
            validatedArgs.maxContentLength = 2000;
          }
          
          if (isLikelyRobustModel && validatedArgs.maxContentLength && validatedArgs.maxContentLength < 5000) {
            this.logger.info(`[MCP] Detected robust model, removing unnecessary content length limit`);
            validatedArgs.maxContentLength = undefined;
          }
          
          this.logger.info(`[MCP] Validated args:`, JSON.stringify(validatedArgs, null, 2));
          this.logger.info(`[MCP] Starting web search...`);
          
          const result = await this.handleWebSearch(validatedArgs);
          this.logger.info(`[MCP] Search completed, found ${result.results.length} results`);
          
          // Format the results
          let responseText = `Search completed for "${result.query}" with ${result.total_results} results:\n\n`;
          if (result.status) responseText += `**Status:** ${result.status}\n\n`;
          
          const maxLength = validatedArgs.maxContentLength;
          
          result.results.forEach((searchResult, idx) => {
            responseText += `**${idx + 1}. ${searchResult.title}**\n`;
            responseText += `URL: ${searchResult.url}\n`;
            responseText += `Description: ${searchResult.description}\n`;
            
            if (searchResult.fullContent && searchResult.fullContent.trim()) {
              let content = searchResult.fullContent;
              if (maxLength && maxLength > 0 && content.length > maxLength) {
                content = content.substring(0, maxLength) + `\n\n[Content truncated at ${maxLength} characters]`;
              }
              responseText += `\n**Full Content:**\n${content}\n`;
            } else if (searchResult.contentPreview && searchResult.contentPreview.trim()) {
              let content = searchResult.contentPreview;
              if (maxLength && maxLength > 0 && content.length > maxLength) {
                content = content.substring(0, maxLength) + `\n\n[Content truncated at ${maxLength} characters]`;
              }
              responseText += `\n**Content Preview:**\n${content}\n`;
            } else if (searchResult.fetchStatus === 'error') {
              responseText += `\n**Content Extraction Failed:** ${searchResult.error}\n`;
            }
            responseText += `\n---\n\n`;
          });
          
          return {
            content: [{ type: 'text' as const, text: responseText }],
          };
        } catch (error) {
          console.error(`[MCP] Error in tool handler:`, error);
          throw error;
        }
      }
    );

    // Register the lightweight web search summaries tool
    this.server.tool(
      'get-web-search-summaries',
      'Search the web and return only the search result snippets/descriptions without following links to extract full page content.',
      {
        query: z.string().describe('Search query to execute'),
        limit: z.number().int().min(1).max(10).default(5).describe('Number of search results to return (1-10)'),
      },
      async (args) => {
        this.logger.info(`[MCP] Tool call received: get-web-search-summaries`);
        try {
          const { query, limit } = args as { query: string; limit: number };
          this.logger.info(`[MCP] Starting web search summaries for: ${query}`);
          
          try {
            const searchResponse = await this.searchEngine.search({ query, numResults: limit });
            const summaryResults = searchResponse.results.map(item => ({
              title: item.title,
              url: item.url,
              description: item.description,
              timestamp: item.timestamp,
            }));

            this.logger.info(`[MCP] Search summaries completed, found ${summaryResults.length} results`);
            
            let responseText = `Search summaries for "${query}" with ${summaryResults.length} results:\n\n`;
            summaryResults.forEach((summary, i) => {
              responseText += `**${i + 1}. ${summary.title}**\n`;
              responseText += `URL: ${summary.url}\n`;
              responseText += `Description: ${summary.description}\n`;
              responseText += `\n---\n\n`;
            });

            return {
              content: [{ type: 'text' as const, text: responseText }],
            };
          } finally {
            try {
              // Since BrowserPool is shared, we don't call closeAll() per-request anymore.
              // Wait for future dedicated cleanup routine if needed, or leave active browsers in pool.
            } catch (cleanupError) {
              this.logger.error(`[MCP] Error during browser cleanup:`, cleanupError);
            }
          }
        } catch (error) {
          this.logger.error(`[MCP] Error in tool handler:`, error);
          throw error;
        }
      }
    );

    // Register the single page content extraction tool
    this.server.tool(
      'get-single-web-page-content',
      'Extract and return the full content from a single web page URL.',
      {
        url: z.string().url().describe('The URL of the web page to extract content from'),
        maxContentLength: z.number().int().min(0).optional().describe('Maximum characters for the extracted content (0 = no limit)'),
      },
      async (args) => {
        this.logger.info(`[MCP] Tool call received: get-single-web-page-content`);
        try {
          const { url, maxContentLength } = args as { url: string; maxContentLength?: number };
          this.logger.info(`[MCP] Starting single page content extraction for: ${url}`);
          
          const content = await this.contentExtractor.extractContent({
            url,
            maxContentLength: maxContentLength === 0 ? undefined : maxContentLength,
          });

          const urlObj = new URL(url);
          const title = urlObj.hostname + urlObj.pathname;
          const wordCount = content.split(/\s+/).filter(word => word.length > 0).length;

          this.logger.info(`[MCP] Single page content extraction completed, extracted ${content.length} characters`);

          let responseText = `**Page Content from: ${url}**\n\n`;
          responseText += `**Title:** ${title}\n`;
          responseText += `**Word Count:** ${wordCount}\n`;
          responseText += `**Content Length:** ${content.length} characters\n\n`;
          
          if (maxContentLength && maxContentLength > 0 && content.length > maxContentLength) {
            responseText += `**Content (truncated at ${maxContentLength} characters):**\n${content.substring(0, maxContentLength)}\n\n[Content truncated at ${maxContentLength} characters]`;
          } else {
            responseText += `**Content:**\n${content}`;
          }

          return {
            content: [{ type: 'text' as const, text: responseText }],
          };
        } catch (error) {
          this.logger.error(`[MCP] Error in tool handler:`, error);
          throw error;
        }
      }
    );
  }

  private async handleWebSearch(input: WebSearchToolInput): Promise<WebSearchToolOutput> {
    const startTime = Date.now();
    const { query, limit = 5, includeContent = true } = input;
    
    this.logger.info(`[web-search-mcp] DEBUG: handleWebSearch called with limit=${limit}, includeContent=${includeContent}`);

    try {
      const searchLimit = includeContent ? Math.min(limit * 2 + 2, 10) : limit;
      this.logger.info(`[web-search-mcp] DEBUG: Requesting ${searchLimit} search results to get ${limit} non-PDF content results`);
      
      const searchResponse = await this.searchEngine.search({
        query,
        numResults: searchLimit,
      });
      const searchResults = searchResponse.results;
      
      const pdfCount = searchResults.filter(result => isPdfUrl(result.url)).length;
      const followedCount = searchResults.length - pdfCount;
      this.logger.info(`[web-search-mcp] DEBUG: Search engine: ${searchResponse.engine}; ${limit} requested/${searchResults.length} obtained; PDF: ${pdfCount}; ${followedCount} followed.`);

      const enhancedResults = includeContent 
        ? await this.contentExtractor.extractContentForResults(searchResults, limit)
        : searchResults.slice(0, limit);
      
      let combinedStatus = `Search engine: ${searchResponse.engine}; ${limit} result requested/${searchResults.length} obtained; PDF: ${pdfCount}; ${followedCount} followed`;
      
      if (includeContent) {
        const successCount = enhancedResults.filter(r => r.fetchStatus === 'success').length;
        const failedResults = enhancedResults.filter(r => r.fetchStatus === 'error');
        const failedCount = failedResults.length;
        
        const failureReasons = this.categorizeFailureReasons(failedResults);
        const failureReasonText = failureReasons.length > 0 ? ` (${failureReasons.join(', ')})` : '';
        
        this.logger.info(`[web-search-mcp] DEBUG: Links requested: ${limit}; Successfully extracted: ${successCount}; Failed: ${failedCount}${failureReasonText}; Results: ${enhancedResults.length}.`);
        combinedStatus += `; Successfully extracted: ${successCount}; Failed: ${failedCount}; Results: ${enhancedResults.length}`;
      }

      const searchTime = Date.now() - startTime;

      return {
        results: enhancedResults,
        total_results: enhancedResults.length,
        search_time_ms: searchTime,
        query,
        status: combinedStatus,
      };
    } catch (error) {
      this.logger.error('Web search error:', error);
      throw new Error(`Web search failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private categorizeFailureReasons(failedResults: SearchResult[]): string[] {
    const reasonCounts = new Map<string, number>();
    failedResults.forEach(result => {
      if (result.error) {
        const category = this.categorizeError(result.error);
        reasonCounts.set(category, (reasonCounts.get(category) || 0) + 1);
      }
    });
    return Array.from(reasonCounts.entries()).map(([reason, count]) => 
      count > 1 ? `${reason} (${count})` : reason
    );
  }

  private categorizeError(errorMessage: string): string {
    const lowerError = errorMessage.toLowerCase();
    if (lowerError.includes('timeout')) return 'Timeout';
    if (lowerError.includes('403')) return 'Access denied';
    if (lowerError.includes('404')) return 'Not found';
    if (lowerError.includes('bot') || lowerError.includes('captcha')) return 'Bot detection';
    if (lowerError.includes('too large')) return 'Content too long';
    if (lowerError.includes('ssl') || lowerError.includes('certificate')) return 'SSL error';
    if (lowerError.includes('network') || lowerError.includes('connection')) return 'Network error';
    return 'Other error';
  }

  private setupGracefulShutdown(): void {
    const shutdown = async () => {
      this.logger.force('Shutting down gracefully...');
      try {
        await Promise.all([
          this.browserPool.closeAll()
        ]);
      } catch (error) {
        this.logger.error('Error during graceful shutdown:', error);
      }
      process.exit(0);
    };

    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  }

  async run(options: { transport: 'stdio' | 'http'; port?: number }): Promise<void> {
    if (options.transport === 'http') {
      const app = express();
      const port = options.port || 8000;
      
      // Use JSON middleware for POST requests
      app.use(express.json());
      
      const transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => crypto.randomUUID(),
      });
      
      await this.server.connect(transport);
      
      // Modern Streamable HTTP uses a single endpoint for both SSE (GET) and Messages (POST)
      app.all('/mcp', (req, res) => {
        transport.handleRequest(req, res, req.body);
      });
      
      app.listen(port, () => {
        this.logger.force(`Web Search MCP Server (HTTP) started on port ${port}`);
        this.logger.force(`MCP endpoint: http://localhost:${port}/mcp`);
      });
    } else {
      const transport = new StdioServerTransport();
      await this.server.connect(transport);
      this.logger.force('Web Search MCP Server (stdio) started');
    }
  }
}

// CLI Setup
const program = new Command();
program
  .name('web-search-mcp')
  .description('Web Search MCP server for local LLMs')
  .version('0.5.1')
  .option('--http', 'Run in HTTP/SSE mode')
  .option('--port <number>', 'Port for HTTP mode', '8000')
  .option('--no-sandbox', 'Disable Playwright sandbox (useful for Docker)', true)
  .action(async (options) => {
    const server = new WebSearchMCPServer({ playwrightNoSandbox: options.sandbox });
    const mode = options.http ? 'http' : 'stdio';
    const port = parseInt(options.port, 10);
    
    server.run({ transport: mode, port }).catch((error) => {
      console.error('Fatal server error:', error); // Use console.error for fatal bootstrap errors
      process.exit(1);
    });
  });

program.parse();
