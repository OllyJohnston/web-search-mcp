#!/usr/bin/env node
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { z } from 'zod';
import express from 'express';
import { Command } from 'commander';
import { SearchEngine } from './search-engine.js';
import { EnhancedContentExtractor } from './enhanced-content-extractor.js';
import { WebSearchToolInput, WebSearchToolOutput, SearchResult, ServerConfig } from './types.js';
import { BrowserPool } from './browser-pool.js';
import { isPdfUrl, Logger } from './utils.js';
import crypto from 'node:crypto';

class WebSearchMCPServer {
  private server: McpServer;
  private searchEngine: SearchEngine;
  private contentExtractor: EnhancedContentExtractor;
  private config: ServerConfig;
  private browserPool: BrowserPool;
  private logger: Logger;
  private isConnected = false;

  constructor(cliConfig?: { playwrightNoSandbox?: boolean }) {
    this.server = new McpServer({
      name: 'web-search-mcp-server',
      version: '0.6.0',
    });

    this.config = this.parseConfig(cliConfig);
    this.logger = new Logger(this.config.verboseLogging);
    
    // Attach MCP protocol logging
    this.logger.setNotificationCallback((level, message) => {
      try {
        if (this.isConnected) {
          // @ts-ignore - access to internal server for notification
          const baseServer = this.server.server;
          if (baseServer) {
            baseServer.notification({
              method: 'notifications/logging/message',
              params: {
                level: level as any,
                data: message,
                logger: 'web-search-mcp'
              }
            });
            return;
          }
        }
      } catch (err) { }
      
      const prefix = level === 'notice' ? '' : `[${level.toUpperCase()}] `;
      console.error(`${prefix}${message}`);
    });

    this.logger.force('Web Search MCP Server v0.6.0 starting...');

    this.browserPool = new BrowserPool(this.config, this.logger);
    this.searchEngine = new SearchEngine(this.config, this.browserPool, this.logger);
    this.contentExtractor = new EnhancedContentExtractor(this.config, this.browserPool, this.logger);

    this.setupTools();
    this.setupGracefulShutdown();
  }

  private parseConfig(cliConfig?: { playwrightNoSandbox?: boolean }): ServerConfig {
    const maxContentLengthParsed = parseInt(process.env.MAX_CONTENT_LENGTH || '500000', 10);
    
    let playwrightNoSandbox = true;
    if (cliConfig?.playwrightNoSandbox !== undefined) {
      playwrightNoSandbox = cliConfig.playwrightNoSandbox;
    } else if (process.env.PLAYWRIGHT_NO_SANDBOX === 'false') {
      playwrightNoSandbox = false;
    }

    return {
      maxContentLength: isNaN(maxContentLengthParsed) || maxContentLengthParsed < 0 ? 500000 : maxContentLengthParsed,
      defaultTimeout: parseInt(process.env.DEFAULT_TIMEOUT || '15000', 10),
      maxBrowsers: parseInt(process.env.MAX_BROWSERS || '3', 10),
      browserHeadless: process.env.BROWSER_HEADLESS !== 'false',
      browserTypes: (process.env.BROWSER_TYPES || 'chromium,firefox').split(',').map(type => type.trim()),
      browserFallbackThreshold: parseFloat(process.env.BROWSER_FALLBACK_THRESHOLD || '0.5'),
      enableRelevanceChecking: process.env.ENABLE_RELEVANCE_CHECKING !== 'false',
      relevanceThreshold: parseFloat(process.env.RELEVANCE_THRESHOLD || '0.3'),
      forceMultiEngineSearch: process.env.FORCE_MULTI_ENGINE_SEARCH === 'true',
      debugBrowserLifecycle: process.env.DEBUG_BROWSER_LIFECYCLE === 'true',
      debugBingSearch: process.env.DEBUG_BING_SEARCH === 'true',
      playwrightNoSandbox,
      verboseLogging: process.env.VERBOSE_LOGGING !== 'false'
    };
  }

  private setupTools(): void {
    this.server.tool(
      'full-web-search',
      'Search the web and fetch complete page content from top results. Feature-rich search with parallel engine orchestration and quality scoring.',
      {
        query: z.string().describe('Search query to execute'),
        limit: z.number().int().min(1).max(10).default(5).describe('Number of results to return with content'),
        includeContent: z.boolean().default(true).describe('Whether to fetch full page content'),
        maxContentLength: z.number().int().min(0).optional().describe('Maximum characters per result content'),
      },
      async (args) => {
        this.logger.info(`[MCP] Tool call received: full-web-search`, JSON.stringify(args));

        try {
          const validatedArgs = args as WebSearchToolInput;
          const GLOBAL_TIMEOUT = 25000;
          const toolDeadline = Date.now() + GLOBAL_TIMEOUT;

          const resultPromise = this.handleWebSearch(validatedArgs, toolDeadline);
          
          const timeoutPromise = new Promise<WebSearchToolOutput>((resolve) => {
            setTimeout(() => {
              this.logger.warn(`[MCP] Global tool deadline hit. Returning partial results.`);
              resolve({
                results: [],
                total_results: 0,
                search_time_ms: GLOBAL_TIMEOUT,
                query: validatedArgs.query,
                status: 'Global tool execution deadline reached. Results may be partial.'
              });
            }, GLOBAL_TIMEOUT);
          });

          const result = await Promise.race([resultPromise, timeoutPromise]);
          
          let responseText = `Search completed for "${result.query}" (${result.results.length} results):\n\n`;
          if (result.status) responseText += `**Status:** ${result.status}\n\n`;
          
          const maxLength = validatedArgs.maxContentLength || this.config.maxContentLength;
          
          result.results.forEach((searchResult, idx) => {
            responseText += `**${idx + 1}. ${searchResult.title}**\n`;
            responseText += `URL: ${searchResult.url}\n`;
            responseText += `Description: ${searchResult.description}\n`;
            
            if (searchResult.fullContent) {
              let content = searchResult.fullContent;
              if (maxLength && content.length > maxLength) {
                content = content.substring(0, maxLength) + `... [Truncated]`;
              }
              responseText += `\n**Full Content:**\n${content}\n`;
            } else if (searchResult.fetchStatus === 'error') {
              responseText += `\n**Content Extraction Failed:** ${searchResult.error}\n`;
            }
            responseText += `\n---\n\n`;
          });
          
          return {
            content: [{ type: 'text' as const, text: responseText }],
          };
        } catch (error) {
          this.logger.error(`[MCP] Error in tool handler:`, error);
          throw error;
        }
      }
    );

    this.server.tool(
      'get-web-search-summaries',
      'Search the web and return only result snippets without content extraction.',
      {
        query: z.string().describe('Search query'),
        limit: z.number().int().min(1).max(10).default(5).describe('Number of results'),
      },
      async (args) => {
        const { query, limit } = args as { query: string; limit: number };
        const result = await this.searchEngine.search({ query, numResults: limit });
        
        let responseText = `Search summaries for "${query}":\n\n`;
        result.results.forEach((item, i) => {
          responseText += `**${i + 1}. ${item.title}**\nURL: ${item.url}\nDescription: ${item.description}\n---\n\n`;
        });

        return { content: [{ type: 'text' as const, text: responseText }] };
      }
    );

    this.server.tool(
      'get-single-web-page-content',
      'Extract full content from a single URL.',
      {
        url: z.string().url().describe('The URL to extract'),
        maxContentLength: z.number().int().min(0).optional().describe('Content limit'),
      },
      async (args) => {
        const { url, maxContentLength } = args as { url: string; maxContentLength?: number };
        const content = await this.contentExtractor.extractContent({ 
          url, 
          maxContentLength: maxContentLength || this.config.maxContentLength 
        });

        return {
          content: [{ 
            type: 'text' as const, 
            text: `**Content from: ${url}**\n\n${content}` 
          }],
        };
      }
    );
  }

  private async handleWebSearch(input: WebSearchToolInput, deadline?: number): Promise<WebSearchToolOutput> {
    const startTime = Date.now();
    const { query, limit = 5, includeContent = true } = input;
    
    const searchResponse = await this.searchEngine.search({
      query,
      numResults: limit,
      forceMultiEngine: this.config.forceMultiEngineSearch
    });

    let results = searchResponse.results;
    if (includeContent) {
      results = await this.contentExtractor.extractContentForResults(results, limit, deadline);
    }

    const successCount = results.filter(r => r.fetchStatus === 'success').length;
    const status = `Engine: ${searchResponse.engine}; Requested: ${limit}; Success: ${successCount}`;

    return {
      results,
      total_results: results.length,
      search_time_ms: Date.now() - startTime,
      query,
      status
    };
  }

  private setupGracefulShutdown(): void {
    const shutdown = async () => {
      this.logger.force('Shutting down gracefully...');
      await this.browserPool.closeAll();
      process.exit(0);
    };
    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  }

  async run(options: { transport: 'stdio' | 'http'; port?: number }): Promise<void> {
    if (options.transport === 'http') {
      const app = express();
      const port = options.port || 8000;
      app.use(express.json());
      const transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => crypto.randomUUID(),
      });
      await this.server.connect(transport);
      this.isConnected = true;
      app.all('/mcp', (req, res) => transport.handleRequest(req, res, req.body));
      app.listen(port, () => {
        this.logger.force(`Web Search MCP Server (HTTP) started on port ${port}`);
      });
    } else {
      const transport = new StdioServerTransport();
      await this.server.connect(transport);
      this.isConnected = true;
      this.logger.force('Web Search MCP Server (stdio) started');
    }
  }
}

const program = new Command();
program
  .name('web-search-mcp')
  .description('Web Search MCP server for local LLMs')
  .version('0.6.0')
  .option('--http', 'Run in HTTP/SSE mode')
  .option('--port <number>', 'Port for HTTP mode', '8000')
  .option('--no-sandbox', 'Disable Playwright sandbox', true)
  .action(async (options) => {
    const server = new WebSearchMCPServer({ playwrightNoSandbox: options.sandbox });
    server.run({ transport: options.http ? 'http' : 'stdio', port: parseInt(options.port, 10) }).catch((err) => {
      console.error('Fatal:', err);
      process.exit(1);
    });
  });

program.parse();
